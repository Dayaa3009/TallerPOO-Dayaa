package com.mycompany.taller7;

import java.util.Scanner;

public class Taller7 {
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int cantidadNumeros, numero, mayoresCero = 0, menoresCero = 0, igualesCero = 0;

        System.out.print("Ingrese la cantidad de números a introducir: ");
        cantidadNumeros = entrada.nextInt();

        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.print("Ingrese un número: ");
            numero = entrada.nextInt();

            if (numero > 0) {
                mayoresCero++;
            } else if (numero < 0) {
                menoresCero++;
            } else {
                igualesCero++;
            }
        }

        System.out.println("Números mayores que 0: " + mayoresCero);
        System.out.println("Números menores que 0: " + menoresCero);
        System.out.println("Números iguales a 0: " + igualesCero);
    }
}